# Abacus Thinking

**A latent-state, multi-mode graph reasoning framework for small open models.**

First testbed: `XHToken/Spark-X2.5-4B` (Apache 2.0).
Author: nutter77 / MC7ever
Status: Phase 0 scoping — repo + paper underway, end of week target.

---

## 1. The Idea

Current chain-of-thought is a single string of words. The model commits to one
token at a time, one path at a time, and everything it "thought" is forced
through text. Abacus Thinking replaces that with an abacus:

- **Frame** — the reasoning graph. Nodes are reasoning states, edges are
  transitions. This is the skeleton everything hangs off.
- **Rods** — parallel reasoning chains through the graph. Three rod classes,
  one per inference mode: **abductive** (hypothesis generation), **deductive**
  (forward-chaining from premises), **inductive** (pattern generalisation).
  Borrowed from Theorem-of-Thought's parallel agents.
- **Beads** — reasoning states on a rod. Three bead types:
  - *word beads* — normal decoded tokens (baseline behaviour)
  - *concept beads* — Soft-Think-style probability-weighted mixtures over the
    embedding space; one position, multiple meanings explored at once
  - *latent beads* — Coconut-style last-hidden-state fed straight back as the
    next input embedding; pure continuous thought, no text at all
- **Rod memory** — an SST-style state stream: a persistent latent cache with
  decay that travels down a rod, so beads have momentum and chains have
  continuity instead of every node being computed cold.
- **External beads** — high-confidence beads spliced onto a rod from outside:
  symbolic solver traces (Logic-Thinker style), retrieved knowledge, or tool
  calls. They replace whole sub-chains with one verified bead.

Path selection across the webbed graph is done by Bayesian belief propagation
over rod traces (from Theorem-of-Thought), replacing ad-hoc best-first scoring.

Why "abacus": the computation is tangible and manipulable. Beads slide
(continuous states), rods are parallel, the frame holds structure, and the
whole thing is operated deliberately rather than generated once and hoped for.

## 2. Why Spark-X2.5-4B

- 4.1B params, 36 layers, hidden 2560, vocab 131,072 — small enough to iterate
  fast, big enough that reasoning gains are measurable.
- **Hybrid attention: 9 global-attention (GA) layers + 27 sliding-window (SWA)
  layers, window 512, GQA 4 KV heads.** This matters a lot for us:
  - The SWA window *is* a natural home for the SST state stream — the decay
    cache and the attention window do the same job at the same scale. Rod
    memory rides the window for free on 27 of 36 layers.
  - Long-range continuity for rods gets injected at the 9 GA layers, where the
    full 1M context is visible. Rod state summaries get flushed to GA layers
    periodically.
  - GQA with 4 KV heads is cheap to cache → running 3 rods (abductive /
    deductive / inductive) in parallel per node is affordable at this size.
- Native **thinking mode** (Qwen3-style reasoning blocks, `enable_thinking`
  default on): the model already segments its output into a reasoning trace.
  Abacus wraps that: think-block segments become rod traces, and verbose
  segments become concept/latent beads. We're upgrading the thinking, not
  bolting on a new mode.
- Apache 2.0, HF Transformers format, vLLM/SGLang/MLX/llama.cpp support → we
  can ship framework code without touching weights in Phase 0, and fine-tune
  with LLaMA-Factory in Phase 1.
- Strong published baselines to beat (thinking mode): AIME 2026 **90.7**,
  HMMT Feb 2026 **81.2**, GPQA **67.4**, SWE-Bench Verified **41.6**,
  IFEval **93.0**.

## 3. Phases

### Phase 0 — Training-free (this week onward)

Everything here runs on stock `Spark-X2.5-4B` weights. No fine-tuning.

1. **Concept beads (Soft Thinking).** At each reasoning step, instead of
   committing to one token, take the top-k next-token distribution and feed a
   probability-weighted mixture of the top-k token embeddings as the next
   input. Abstract concept positions, multiple paths explored implicitly.
   Expected: pass@1 up a couple points, tokens down ~20%.
2. **State stream (SST) rod memory.** Maintain a per-rod latent cache:
   sliding window, exponential decay, carried across bead positions on that
   rod. Weight-free, architecture-level. On Spark: trivially compatible with
   the 27 SWA layers; the stream's long-range summary gets written into the
   9 GA layers' KV at segment boundaries.
3. **Frame + rods (ToTh).** Build the reasoning graph: at each node, spawn
   abductive/deductive/inductive rods, collect traces, assemble the graph,
   run Bayesian belief propagation, pick the winning path. This is the
   scheduler and the scorer.
4. **External beads.** Logic-Thinker-style solver calls for formalisable
   sub-problems; GIVE-style retrieval splice for knowledge-heavy ones.
   Solver output gets summarised into a compact trace and placed as a single
   high-confidence bead on the rod.

**Phase 0 success criteria:** beats stock Spark-X2.5-4B thinking-mode on
AIME 2026 / HMMT-style math and GPQA at equal-or-lower token cost, measured
pass@1 with fixed seeds.

### Phase 1 — Trained (latent beads)

1. **Coconut-style fine-tune**: teach Spark to emit latent beads — segments
   where the last hidden state is fed back as the next embedding instead of
   decoding. BFS in latent space: multiple candidate next-bead states kept
   alive before commitment. This is the flagship capability.
2. Use **LoRA/adapters**, not full fine-tunes — we merge and remix models
   constantly, and adapters keep Abacus portable across the merge lineup.
   LLaMA-Factory for the training loop.
3. **Darwin** tunes the thinking layer: when to emit word vs concept vs latent
   beads, how deep rods run, propagation schedules. The knobs live in the
   thinking layer, not just the weights.

**Long pole — start now:** the latent-bead training corpus. Problems paired
with reasoning traces where segments are replaced by latent states. Curate
during Phase 0.

### Phase 2 — Hybrid (the real thing)

Word + concept + latent beads coexisting, model chooses bead type per node,
SST carries continuity across all three, belief propagation scores mixed-type
paths, external beads splice in. Nobody has this combination:
multi-inference-mode graph + persistent rod memory + three bead vocabularies
+ symbolic/retrieval splicing. That's the paper.

## 4. Component Spec (Phase 0)

```
abacus/
  frame.py        # reasoning graph: nodes, edges, web structure
  beads.py        # bead types: WordBead, ConceptBead, (LatentBead stub)
  rods.py         # rod classes: AbductiveRod, DeductiveRod, InductiveRod
                  # + SST state stream (window, decay, GA flush)
  propagate.py    # Bayesian belief propagation over rod traces
  external.py     # solver beads + retrieval beads (splice interface)
  engine.py       # the loop: node -> spawn rods -> collect -> propagate -> advance
  eval/
    baseline.py   # stock Spark thinking-mode runs, fixed seeds
    abacus.py     # same problems through the engine
    report.py     # pass@1, tokens-used, cost deltas
```

Engine loop:

1. Frame gives current frontier node(s).
2. Spawn one rod per inference mode; each rod decodes with its state stream.
3. Concept beads active by default; word beads on high-confidence positions.
4. Node scores its beads; solver/retrieval consulted when tagged.
5. Belief propagation updates edge weights; winning edge extends the frame.
6. Repeat until answer bead or budget exhausted.

## 5. End-of-Week Plan (get it underway)

- **Day 1–2:** repo skeleton; `beads.py` concept-bead prototype running
  against Spark via HF Transformers; first AIME-style smoke test.
- **Day 3:** `frame.py` + `rods.py`; three-mode rods with belief propagation
  selecting paths; SST state stream riding the SWA window.
- **Day 4:** eval harness — baseline vs abacus on a fixed math + GPQA subset;
  log tokens and pass@1.
- **Day 5:** paper skeleton (arXiv format) + README with the metaphor and the
  Phase 0 results-to-date; push to GitHub + HF.

## 6. Publication Route

1. GitHub repo (code, docs, process log) — living documentation.
2. Hugging Face (models/spaces, anything weight-related).
3. arXiv preprint once Phase 0 numbers exist.
4. Reports also go up via OpenAlex-indexed venues and Wolfram Alpha's
   publication channel as they accept them.
5. Process documented publicly as we go — the "how" is part of the story.

## 7. Risks / Open Questions

- **Concept-bead fidelity on Spark's vocab (131k):** mixture-of-embeddings
  quality depends on embedding geometry; measure drift early, fall back to
  top-1 with soft lookahead if mixtures smear.
- **SST × SWA interaction:** the state stream and the attention window overlap
  but aren't identical — the stream must be flushed to GA layers explicitly or
  rods lose long-range coherence. Watch this in ablations.
- **Belief propagation cost:** on a webbed graph with 3 rods/node it can
  dominate runtime. Budget it; approximate propagation if needed.
- **Thinking-mode interplay:** Spark's trained thinking format may fight the
  bead segmentation. If so, treat think-blocks as rod-trace containers and
  bead only inside them first.
- **Sampling params:** card recommends temp 1.0 / top_p 0.95 for thinking
  mode; concept beads change the effective distribution — retune per rod class.

## 8. License

Apache 2.0 (matches Spark-X2.5 and the broader ecosystem).
