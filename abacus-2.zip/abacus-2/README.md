# Abacus Thinking

Latent-state, multi-mode graph reasoning for small open models.
First testbed: XHToken/Spark-X2.5-4B (Apache 2.0).

See MASTER_PROMPT.md for the full spec given to the build agent.

## The metaphor
- Frame = reasoning graph (nodes = states, edges = transitions)
- Rods = parallel chains, one per inference mode (abductive / deductive / inductive)
- Beads = reasoning states: word beads, concept beads (Soft Thinking), latent beads (Coconut, Phase 1)
- Rod memory = SST state stream (sliding window + decay, flushed to GA layers)
- External beads = solver/retrieval splices (high-confidence single beads)

## Quickstart
    pip install -r requirements.txt
    python -m abacus.engine --model XHToken/Spark-X2.5-4B --prompt "test"
    python eval/baseline.py --model XHToken/Spark-X2.5-4B --limit 20
    python eval/abacus_eval.py --model XHToken/Spark-X2.5-4B --limit 20
    python eval/report.py

## Phase 0 = training-free. No weight changes. Everything is inference-time.
