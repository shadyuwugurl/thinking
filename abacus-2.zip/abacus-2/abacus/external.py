"""External beads: solver + retrieval splices (Logic-Thinker / GIVE style).

A sub-problem that can be formalised or looked up becomes ONE high-confidence
bead on the rod instead of a long model-generated sub-chain.
Phase 0: both off by default (see AbacusConfig).
"""
from .beads import Bead, BeadType


class SolverBead:
    """Symbolic solver splice. TODO(vibe): wire an actual solver
    (e.g. z3 for logic, sympy for algebra). Returns compact trace."""

    def solve(self, problem: str):
        # TODO: detect formalisable problem, run solver, summarise to short trace
        return None


class RetrievalBead:
    """Knowledge splice. TODO(vibe): plug in a retriever over a trusted corpus;
    place retrieved fact as a single retrieval bead with source citation."""

    def retrieve(self, query: str):
        # TODO: retrieval call -> Bead(type=RETRIEVAL, text=fact, source=...)
        return None


def maybe_external(problem: str, cfg) -> Bead | None:
    if cfg.solver_enabled:
        b = SolverBead().solve(problem)
        if b:
            return b
    if cfg.retrieval_enabled:
        return RetrievalBead().retrieve(problem)
    return None
