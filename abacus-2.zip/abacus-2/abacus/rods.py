"""Rods: parallel reasoning chains, one per inference mode, with SST memory.

Rod classes (ToTh): abductive (hypothesise), deductive (chain forward),
inductive (generalise from examples). Each rod carries its own SST state
stream: sliding-window latent cache with decay, flushed to GA layers.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from collections import deque
import torch


ROAD_PROMPTS = {
    "abductive": "Consider possible explanations or hypotheses. Branch freely.",
    "deductive": "Reason strictly forward from the given premises, step by step.",
    "inductive": "Look for patterns and generalise from concrete examples.",
}


class StateStream:
    """SST: persistent latent state for a rod. Sliding window + exp decay.

    Spark has 27 SWA layers (window 512) + 9 GA layers. The stream lives in
    the window; every flush_every positions a decayed summary is written
    into the GA-layer KV so the rod keeps long-range coherence.
    """

    def __init__(self, hidden_size: int, window: int = 512, decay: float = 0.95,
                 flush_every: int = 128):
        self.hidden_size = hidden_size
        self.window = window
        self.decay = decay
        self.flush_every = flush_every
        self.buf: deque = deque(maxlen=window)
        self.ga_summary = None
        self._since_flush = 0

    def push(self, h: torch.Tensor):
        self.buf.append(h.detach())
        self._since_flush += 1
        if self._since_flush >= self.flush_every:
            self.flush()

    def flush(self):
        if not self.buf:
            return
        w = torch.tensor([self.decay ** (len(self.buf) - 1 - i) for i in range(len(self.buf))])
        stacked = torch.stack(list(self.buf))
        self.ga_summary = (stacked * w.unsqueeze(-1).to(stacked.device)).sum(0) / w.sum()
        self._since_flush = 0

    def context_vector(self):
        """Bias added to current hidden state before next bead. Phase 0 uses a
        fixed small coefficient (ablate later)."""
        if self.ga_summary is None:
            return None
        return 0.1 * self.ga_summary


@dataclass
class Rod:
    mode: str                     # abductive | deductive | inductive
    beads: list = field(default_factory=list)
    stream: StateStream | None = None
    alive: bool = True
    score: float = 0.0            # filled by belief propagation

    def __post_init__(self):
        if self.stream is None:
            self.stream = StateStream(hidden_size=2560)  # Spark hidden

    @property
    def trace(self) -> str:
        return "".join(b.text or "" for b in self.beads if b.text)
