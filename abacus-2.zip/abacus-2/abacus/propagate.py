"""Belief propagation over the frame (from Theorem-of-Thought).

Rods emit traces; traces become evidence on edges; propagation selects the
most coherent reasoning graph. Phase 0 uses loopy BP with a fixed iteration
budget -- approximate but bounded.
"""
from .frame import Frame


def trace_coherence(trace: str) -> float:
    """Heuristic evidence score for a rod trace. Phase 0: length + structure
    heuristics. TODO(vibe): swap for a trained verifier or LLM-judge later."""
    if not trace.strip():
        return 0.0
    score = min(len(trace) / 500.0, 1.0)
    for marker in ("therefore", "because", "thus", "so ", "implies"):
        score += 0.05 * trace.lower().count(marker)
    return min(score, 2.0)


def propagate(frame: Frame, budget: int = 64) -> Frame:
    """Loopy belief propagation: edge weight = f(evidence from child traces)."""
    for _ in range(budget):
        delta = 0.0
        for e in frame.edges:
            child = frame.nodes[e.dst]
            ev = max((trace_coherence(t) for t in child.rod_traces.values()), default=0.0)
            new_w = 0.5 * e.weight + 0.5 * ev
            delta = max(delta, abs(new_w - e.weight))
            e.weight = new_w
        if delta < 1e-3:
            break
    return frame
