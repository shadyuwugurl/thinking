"""Frame: the reasoning graph. Nodes are states, edges are transitions.

Webbed structure: a node may have several parent edges (merge points) and
several children (branch points). Belief propagation runs over this graph.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import itertools


@dataclass
class Node:
    id: int
    prompt: str                      # what the rods at this node were asked
    rod_traces: dict = field(default_factory=dict)  # mode -> trace text
    depth: int = 0
    terminal: bool = False


@dataclass
class Edge:
    src: int
    dst: int
    weight: float = 1.0              # updated by belief propagation
    evidence: dict = field(default_factory=dict)


class Frame:
    def __init__(self, root_prompt: str, max_nodes: int = 200):
        self.max_nodes = max_nodes
        self.nodes: dict[int, Node] = {}
        self.edges: list[Edge] = []
        self._ids = itertools.count()
        self.root = self.add_node(root_prompt, depth=0)

    def add_node(self, prompt: str, depth: int) -> Node:
        if len(self.nodes) >= self.max_nodes:
            raise RuntimeError("Frame budget exhausted")
        n = Node(id=next(self._ids), prompt=prompt, depth=depth)
        self.nodes[n.id] = n
        return n

    def link(self, src: Node, dst: Node):
        self.edges.append(Edge(src=src.id, dst=dst.id))

    def parents(self, node_id: int) -> list[int]:
        return [e.src for e in self.edges if e.dst == node_id]

    def children(self, node_id: int) -> list[int]:
        return [e.dst for e in self.edges if e.src == node_id]

    def best_path(self) -> list[int]:
        """Greedy walk from root following max edge weights."""
        path = [self.root.id]
        while True:
            kids = [(e.weight, e.dst) for e in self.edges if e.src == path[-1]]
            if not kids:
                return path
            path.append(max(kids)[1])
