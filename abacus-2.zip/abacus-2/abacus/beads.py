"""Bead types: the reasoning states that sit on rods.

Phase 0 implements WordBead and ConceptBead (Soft Thinking).
LatentBead is the Phase 1 (Coconut) stub.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
import torch


class BeadType(str, Enum):
    WORD = "word"
    CONCEPT = "concept"
    LATENT = "latent"        # Phase 1
    SOLVER = "solver"        # external splice
    RETRIEVAL = "retrieval"  # external splice


@dataclass
class Bead:
    type: BeadType
    text: str | None = None                  # word beads: decoded text
    embedding: torch.Tensor | None = None    # concept/latent beads: continuous state
    confidence: float = 0.0
    source: str = "model"                    # or "solver" / "retrieval"
    meta: dict = field(default_factory=dict)


class SoftThinking:
    """Concept beads: probability-weighted mixture of top-k token embeddings.

    Instead of committing to argmax token, feed sum_i p_i * E[tok_i] as the
    next input embedding. One position explores multiple meanings at once.
    """

    def __init__(self, model, cfg):
        self.model = model
        self.cfg = cfg
        self.embed = model.get_input_embeddings()  # nn.Embedding, 131072 x 2560

    def next_concept(self, logits: torch.Tensor):
        """From next-token logits, build a concept bead + mixture embedding.

        Returns (bead, mixture_embedding_to_feed). If top-1 confidence clears
        the threshold, caller should fall back to a WordBead instead.
        """
        probs = torch.softmax(logits / self.cfg.temperature, dim=-1)
        top_p, top_i = probs.topk(self.cfg.concept_top_k, dim=-1)
        top_p = top_p / top_p.sum()  # renormalise over the mixture
        mixture = (self.embed(top_i.squeeze(0)) * top_p.squeeze(0).unsqueeze(-1)).sum(0)
        confidence = probs.max().item()
        bead = Bead(
            type=BeadType.CONCEPT,
            embedding=mixture,
            confidence=confidence,
            meta={"mixture_ids": top_i.squeeze(0).tolist(),
                  "mixture_p": top_p.squeeze(0).tolist()},
        )
        return bead, mixture

    def mixture_to_text(self, bead: Bead, k: int = 5) -> str:
        """Approximate what a concept bead 'means': nearest decoded tokens."""
        assert bead.embedding is not None
        sims = torch.matmul(self.embed.weight, bead.embedding)
        top = sims.topk(k)
        return " | ".join(
            f"{self.tok.decode([i])}({p:.2f})"
            for p, i in zip(top.values.tolist(), top.indices.tolist())
        )


class LatentBead:
    """Phase 1 stub -- Coconut. Last hidden state fed back as next input
    embedding, no decoding. Phase 1: fine-tune (LoRA) Spark to emit these."""

    def __init__(self, *_):
        raise NotImplementedError("Latent beads land in Phase 1 (Coconut + LoRA).")
