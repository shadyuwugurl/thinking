"""Engine: the loop that runs the abacus.

node -> spawn rods (one per mode) -> rods decode beads with state streams ->
belief propagation -> extend frame along winning edge -> repeat.
"""
from __future__ import annotations
import argparse
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .config import AbacusConfig
from .beads import Bead, BeadType, SoftThinking
from .rods import Rod, ROAD_PROMPTS
from .frame import Frame
from .propagate import propagate


class AbacusEngine:
    def __init__(self, cfg: AbacusConfig | None = None):
        self.cfg = cfg or AbacusConfig()
        self.tok = AutoTokenizer.from_pretrained(self.cfg.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            self.cfg.model_name, torch_dtype=torch.bfloat16, device_map="auto"
        )
        self.model.eval()
        self.soft = SoftThinking(self.model, self.cfg)
        self.soft.tok = self.tok  # for mixture_to_text

    def run_rod(self, rod: Rod, prompt: str, max_beads: int) -> Rod:
        """Decode one rod: concept beads by default, word beads on high
        confidence. Feeds mixture embeddings directly as inputs_embeds."""
        msgs = [{"role": "system", "content": ROAD_PROMPTS[rod.mode]},
                {"role": "user", "content": prompt}]
        ids = self.tok.apply_chat_template(
            msgs, add_generation_prompt=True, return_tensors="pt").to(self.model.device)
        past = None
        emb = None
        text_out = []
        for _ in range(max_beads):
            out = self.model(
                input_ids=ids if past is None else None,
                inputs_embeds=None if past is None else emb.unsqueeze(0).unsqueeze(0),
                past_key_values=past,
                use_cache=True,
                output_hidden_states=True,
            )
            past = out.past_key_values
            logits = out.logits[:, -1, :]
            bead, emb = self.soft.next_concept(logits)
            if bead.confidence >= self.cfg.concept_threshold:
                tok_id = logits.argmax(-1)
                word = self.tok.decode(tok_id)
                text_out.append(word)
                emb = self.model.get_input_embeddings()(tok_id)
                rod.beads.append(Bead(type=BeadType.WORD, text=word,
                                      confidence=bead.confidence))
            else:
                rod.beads.append(bead)
            rod.stream.push(out.hidden_states[-1][:, -1].squeeze(0))
            ids = None
            if "<|im_end|>" in "".join(text_out):
                break
        rod.score = len(text_out)  # placeholder until propagation fills it
        return rod

    def think(self, prompt: str, max_nodes: int | None = None) -> str:
        cfg = self.cfg
        frame = Frame(prompt, max_nodes or cfg.max_nodes)
        frontier = frame.root
        for _ in range(cfg.max_nodes):
            rods = {}
            for mode in cfg.rod_classes:
                rod = self.run_rod(Rod(mode=mode), frontier.prompt,
                                   cfg.max_beads_per_rod)
                rods[mode] = rod
            frontier.rod_traces = {m: r.trace for m, r in rods.items()}
            propagate(frame, cfg.propagation_budget)
            winner = max(rods.values(), key=lambda r: r.score)
            # TODO(vibe): advance the frame -- child node from winning rod's
            # trace, splice external beads, termination check. For now return
            # the winning trace.
            return winner.trace or max(frontier.rod_traces.values(), key=len)
        return ""


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="XHToken/Spark-X2.5-4B")
    p.add_argument("--prompt",
                   default="If a train travels 60 km/h for 2.5 hours, how far does it go?")
    a = p.parse_args()
    eng = AbacusEngine(AbacusConfig(model_name=a.model))
    print(eng.think(a.prompt))


if __name__ == "__main__":
    main()
