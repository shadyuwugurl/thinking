from pydantic import BaseModel


class AbacusConfig(BaseModel):
    # Spark-X2.5-4B architecture facts (from model card)
    model_name: str = "XHToken/Spark-X2.5-4B"
    num_layers: int = 36
    global_attn_layers: int = 9          # GA layers carry long-range
    swa_window: int = 512                # SWA window == SST stream home
    kv_heads: int = 4                    # GQA: cheap parallel rods
    hidden_size: int = 2560
    vocab_size: int = 131072

    # Sampling (card recommends temp=1.0 top_p=0.95 for thinking mode; retune per rod)
    temperature: float = 1.0
    top_p: float = 0.95
    top_k: int = -1

    # Beads
    concept_top_k: int = 8               # Soft Thinking: mixture width
    concept_threshold: float = 0.6       # below this confidence, commit to word bead

    # SST state stream
    stream_decay: float = 0.95           # exponential decay per position
    stream_flush_every: int = 128        # flush long-range summary to GA layers

    # Frame / propagation
    max_nodes: int = 200                 # graph budget
    max_beads_per_rod: int = 256
    rod_classes: tuple = ("abductive", "deductive", "inductive")
    propagation_budget: int = 64         # belief propagation iterations cap

    # External beads
    solver_enabled: bool = False         # Logic-Thinker style, off by default
    retrieval_enabled: bool = False      # GIVE style, off by default

    # Eval
    seed: int = 0
