# UBER MASTER PROMPT -- build the Abacus Thinking repo

You are a senior ML engineer. Build/complete the repo described below. Do not
ask questions; make sensible engineering decisions, mark anything uncertain
with TODO(vibe), and keep everything Phase 0 (training-free, inference-time
only). Write clean, typed, documented Python. No training code.

## Context
Target model: XHToken/Spark-X2.5-4B (HF, Apache 2.0). Architecture facts:
36 layers (9 global attention + 27 sliding window, SWA window 512), GQA with
4 KV heads, hidden 2560, vocab 131,072, native thinking mode (Qwen3-style
think blocks, enable_thinking default ON), recommended sampling temp=1.0
top_p=0.95, works in HF Transformers / vLLM / SGLang / MLX.

## Concept (name things exactly like this)
Abacus Thinking: reasoning as an abacus.
- Frame = reasoning graph (nodes=states, edges=transitions, webbed: merges+branches)
- Rods = parallel chains, one per inference mode: abductive, deductive, inductive
- Beads = reasoning states:
    * word beads = normal decoded tokens
    * concept beads = Soft Thinking: probability-weighted mixture of top-k token
      embeddings fed as the next input embedding, instead of committing to argmax
    * latent beads = Coconut (Phase 1 stub only, must raise NotImplementedError)
- Rod memory = SST state stream: per-rod sliding-window latent cache (window 512)
  with exponential decay (0.95); every 128 positions a decayed summary is flushed
  so the 9 GA layers carry long-range rod coherence (the 27 SWA layers already
  operate at window 512)
- External beads = solver/retrieval splices (Logic-Thinker / GIVE style),
  interface only, disabled by default via config
- Path selection = loopy Bayesian belief propagation over rod traces
  (Theorem-of-Thought style), fixed iteration budget

A scaffold exists (abacus/ and eval/ packages). Keep the structure, the names,
and the metaphor. Your job: make it actually work end to end, fill every
TODO(vibe) you can, and leave a clear note on any you cannot.

## Hard requirements
1. Phase 0 only. No fine-tuning, no weight changes. LatentBead stays a stub.
2. run_rod must really feed concept-bead mixture embeddings as inputs_embeds
   on subsequent steps (that is the entire point of Soft Thinking). Verify the
   inputs_embeds + use_cache path works on this model; fix the scaffold if the
   forward signature differs.
3. Every component unit-importable; the engine CLI runs end to end on one
   GSM8K problem on a single GPU before you call it done.
4. Fixed seeds everywhere; eval arms must be directly comparable.
5. Log per-problem: ok/fail, tokens used, bead-type counts. JSON only.
6. Spark specifics: use apply_chat_template with add_generation_prompt=True;
   thinking mode ON; trust_remote_code only if actually required.
7. The engine loop must: spawn 3 rods per node, collect traces, run belief
   propagation, pick a winning rod, create a child node on the frame from the
   winning trace, check termination, and continue until answer or budget. The
   scaffold currently returns after one node -- finish the loop.

## Known sharp edges (handle these)
- Concept-bead fidelity: mixtures can smear on a 131k vocab. Add a diagnostic
  that reports average mixture entropy per rod; if entropy is too high the
  embeddings blur, so log it.
- SST x SWA: the state stream and the attention window overlap but are not the
  same thing. The GA flush must actually happen or rods lose long-range
  coherence -- wire the context_vector() into the decode loop properly.
- Belief propagation cost: cap iterations (budget in config); approximate if
  the graph is wide.
- Thinking-mode interplay: Spark's trained think-blocks may fight bead
  segmentation. If so, treat think-block content as rod-trace containers and
  bead only inside them first. Document which mode you used.
- Termination: decide and implement when the abacus stops (answer bead,
  confidence plateau, budget).

## Acceptance criteria
- python -m abacus.engine --model XHToken/Spark-X2.5-4B --prompt "..." prints a
  coherent answer with mixed bead usage (word + concept).
- eval/baseline.py and eval/abacus_eval.py both run --limit 5 without crashing.
- eval/report.py prints the comparison table.
- README quickstart works verbatim from a fresh clone.

## Style
Plain, direct docs, no fluff. Docstrings on every public class/function. Type
hints everywhere. The code goes on GitHub + Hugging Face and will be read.
