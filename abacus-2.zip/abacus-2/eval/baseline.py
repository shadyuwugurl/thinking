"""Baseline: stock Spark thinking-mode on the eval subset. Fixed seed."""
import argparse, json
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from datasets import load_dataset


def run(model_name: str, limit: int, seed: int, out: str):
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name, torch_dtype=torch.bfloat16, device_map="auto")
    model.eval()
    torch.manual_seed(seed)
    ds = load_dataset("gsm8k", "main", split=f"test[:{limit}]")
    results = []
    for ex in ds:
        msgs = [{"role": "user", "content": ex["question"]}]
        ids = tok.apply_chat_template(msgs, add_generation_prompt=True,
                                      return_tensors="pt").to(model.device)
        with torch.no_grad():
            out_ids = model.generate(ids, max_new_tokens=2048, do_sample=True,
                                     temperature=1.0, top_p=0.95)
        text = tok.decode(out_ids[0][ids.shape[1]:], skip_special_tokens=True)
        pred = text.split("####")[-1].strip() if "####" in text else text[-50:]
        ok = str(ex["answer"].split("####")[-1].strip()) in pred
        results.append({"q": ex["question"], "gold": ex["answer"], "pred": pred,
                        "ok": ok, "tokens": out_ids.shape[1] - ids.shape[1]})
    acc = sum(r["ok"] for r in results) / len(results)
    toks = sum(r["tokens"] for r in results) / len(results)
    json.dump({"acc": acc, "avg_tokens": toks, "results": results}, open(out, "w"), indent=2)
    print(f"baseline acc={acc:.3f} avg_tokens={toks:.0f} -> {out}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="XHToken/Spark-X2.5-4B")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", default="eval/baseline_results.json")
    a = p.parse_args()
    run(a.model, a.limit, a.seed, a.out)
