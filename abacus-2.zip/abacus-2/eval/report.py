"""Compare baseline vs abacus results. Prints the table for the paper."""
import json


def load(p):
    try:
        return json.load(open(p))
    except FileNotFoundError:
        return None


b = load("eval/baseline_results.json")
a = load("eval/abacus_results.json")
print(f"{'':12} {'acc':>8} {'avg_tokens':>10}")
if b:
    print(f"{'baseline':12} {b['acc']:8.3f} {b['avg_tokens']:10.0f}")
if a:
    print(f"{'abacus':12} {a['acc']:8.3f} {a['avg_tokens']:10.0f}")
if b and a:
    print(f"\ndelta acc={a['acc']-b['acc']:+.3f}  tokens={a['avg_tokens']-b['avg_tokens']:+.0f}")
