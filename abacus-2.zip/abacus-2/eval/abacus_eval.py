"""Abacus arm: same subset through the engine. Same seeds, same problems."""
import argparse, json, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from datasets import load_dataset
from abacus.engine import AbacusEngine
from abacus.config import AbacusConfig


def run(model_name: str, limit: int, seed: int, out: str):
    cfg = AbacusConfig(model_name=model_name, seed=seed)
    eng = AbacusEngine(cfg)
    ds = load_dataset("gsm8k", "main", split=f"test[:{limit}]")
    results = []
    for ex in ds:
        trace = eng.think(ex["question"])
        pred = trace.split("####")[-1].strip() if "####" in trace else trace[-50:]
        ok = str(ex["answer"].split("####")[-1].strip()) in pred
        results.append({"q": ex["question"], "gold": ex["answer"], "pred": pred,
                        "ok": ok, "tokens": len(trace) // 4})  # TODO: real token count
    acc = sum(r["ok"] for r in results) / len(results)
    toks = sum(r["tokens"] for r in results) / len(results)
    json.dump({"acc": acc, "avg_tokens": toks, "results": results}, open(out, "w"), indent=2)
    print(f"abacus acc={acc:.3f} avg_tokens={toks:.0f} -> {out}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="XHToken/Spark-X2.5-4B")
    p.add_argument("--limit", type=int, default=50)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out", default="eval/abacus_results.json")
    a = p.parse_args()
    run(a.model, a.limit, a.seed, a.out)
